package bg.softuni.resttemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResttemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
